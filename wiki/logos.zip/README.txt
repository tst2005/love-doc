Logos
Some users asked for L�VE logos in various formats and sizes, so here they are. Please note that some logos are white-on-transparent, and may appear invisible in your browser.

All artwork in this section is licensed under the ZLIB license, like the rest of L�VE. 